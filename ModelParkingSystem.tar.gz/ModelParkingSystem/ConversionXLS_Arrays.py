

def leerDatos(a,b):
    return str(a)+"+"+str(b)
    

